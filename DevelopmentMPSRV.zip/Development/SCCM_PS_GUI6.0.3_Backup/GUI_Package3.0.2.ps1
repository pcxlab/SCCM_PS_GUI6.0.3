﻿# File GUI_Package.ps1

# ================================
# SCCM Package GUI Tool
# ================================

Clear-Host
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName PresentationFramework


"F:\Development\SCCM_PS_GUI6.0.3\Functions.ps1"
"F:\Development\SCCM_PS_GUI6.0.3\Package Function_V0.8.4.0.ps1"
"F:\Development\SCCM_PS_GUI6.0.3\Connect-PCXCMSite.ps1"
"F:\Development\SCCM_PS_GUI6.0.3\New-PCXCMFolder_V02.03.02_A.ps1"
"F:\Development\SCCM_PS_GUI6.0.3\Get-PCXCMSiteCode.ps1"

<#
. "$PSScriptRoot\Functions.ps1"
. "$PSScriptRoot\Package Function_V0.8.4.0.ps1"
. "$PSScriptRoot\Connect-PCXCMSite.ps1"
. "$PSScriptRoot\New-PCXCMFolder_V02.03.02_A.ps1"
. "$PSScriptRoot\Get-PCXCMSiteCode.ps1"

#>
# Connect SCCM
#
# Press 'F5' to run this script. Running this script will load the ConfigurationManager
# module for Windows PowerShell and will connect to the site.
#
# This script was auto-generated at '8/14/2025 10:42:50 AM'.

# Site configuration
$SiteCode = "CSS" # Site code 
$ProviderMachineName = "SRVBAN19CASVM01.corp.mphasis.com" # SMS Provider machine name

# Customizations
$initParams = @{}
#$initParams.Add("Verbose", $true) # Uncomment this line to enable verbose logging
#$initParams.Add("ErrorAction", "Stop") # Uncomment this line to stop the script on any errors

# Do not change anything below this line

# Import the ConfigurationManager.psd1 module 
if((Get-Module ConfigurationManager) -eq $null) {
    Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" @initParams 
}

# Connect to the site's drive if it is not already present
if((Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue) -eq $null) {
    New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $ProviderMachineName @initParams
}

# Set the current location to be the site code.
Set-Location "$($SiteCode):\" @initParams


# ================================
# XAML UI
# ================================
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="SCCM Package Tool" Height="450" Width="400">

    <Grid Margin="10">

        <Label Content="Source Path:" VerticalAlignment="Top"/>
        <!--TextBox Name="txtSourcePath" Margin="0,25,0,0" Height="25" VerticalAlignment="Top"/-->

        <TextBox Name="txtSourcePath" Margin="0,25,80,0" Height="25" VerticalAlignment="Top"/>

        <Button Name="btnBrowse" Content="..." Width="60" Height="25"
        Margin="0,25,0,0" HorizontalAlignment="Right" VerticalAlignment="Top"/>

        <Label Content="Package Name:" Margin="0,60,0,0" VerticalAlignment="Top"/>
        <TextBox Name="txtPackageName" Margin="0,85,0,0" Height="25" VerticalAlignment="Top" IsReadOnly="True"/>

        <Label Content="Company:" Margin="0,120,0,0" VerticalAlignment="Top"/>
        <TextBox Name="txtCompany" Margin="0,145,0,0" Height="25" VerticalAlignment="Top" IsReadOnly="True"/>

        <Label Content="Product:" Margin="0,180,0,0" VerticalAlignment="Top"/>
        <TextBox Name="txtProduct" Margin="0,205,0,0" Height="25" VerticalAlignment="Top" IsReadOnly="True"/>

        <Label Content="Version:" Margin="0,240,0,0" VerticalAlignment="Top"/>
        <TextBox Name="txtVersion" Margin="0,265,0,0" Height="25" VerticalAlignment="Top" />

        <Button Name="btnCreatePackage" Content="Create Package" Height="30" Margin="0,310,0,0" VerticalAlignment="Top"/>

        <TextBlock Name="txtStatus" Margin="0,350,0,0" Height="60" TextWrapping="Wrap"/>

    </Grid>
</Window>
"@

# ================================
# Load UI
# ================================
$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

# ================================
# Get Controls
# ================================
$txtSourcePath   = $window.FindName("txtSourcePath")
$txtPackageName  = $window.FindName("txtPackageName")
$txtCompany      = $window.FindName("txtCompany")
$txtProduct      = $window.FindName("txtProduct")
$txtVersion      = $window.FindName("txtVersion")
$btnCreatePackage = $window.FindName("btnCreatePackage")
$txtStatus       = $window.FindName("txtStatus")
$btnBrowse       = $window.FindName("btnBrowse")

# ================================
# Auto-fill from Path
# ================================
$txtSourcePath.Add_TextChanged({

    $path = $txtSourcePath.Text

    if ([string]::IsNullOrWhiteSpace($path)) {
        return
    }

    try {
        $pathSplit = $path -split "\\"

        if ($pathSplit.Count -lt 3) {
            return
        }

        $packageName = $pathSplit[-1]
        $company     = $pathSplit[-3]
        $product     = $pathSplit[-2]

        $versionSplit = $packageName -split "_"
        $version = $versionSplit[-1]

        # Populate UI
        $txtPackageName.Text = $packageName
        $txtCompany.Text     = $company
        $txtProduct.Text     = $product
        $txtVersion.Text     = $version
    }
    catch {
        # silent
    }
})

# ================================
# Browse Button (Explorer Style)
# ================================
$btnBrowse.Add_Click({

    $openFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $openFileDialog.Title = "Select any file inside the Package folder"
    $openFileDialog.InitialDirectory = "C:\"
    $openFileDialog.Filter = "All files (*.*)|*.*"

    if ($openFileDialog.ShowDialog() -eq "OK") {

        # Get folder from selected file
        $folderPath = Split-Path $openFileDialog.FileName -Parent

        # Set to textbox (this will trigger auto-fill automatically)
        $txtSourcePath.Text = $folderPath
    }

})

# ================================
# Button Click
# ================================
$btnCreatePackage.Add_Click({

    $srcPath = $txtSourcePath.Text

    if ([string]::IsNullOrWhiteSpace($srcPath)) {
        $txtStatus.Text = "Enter Source Path!"
        return
    }

    try {
        $txtStatus.Text = "Running package creation..."

        # CALL YOUR FUNCTION (NO CHANGE)
        Create-Package -Path $srcPath

        $txtStatus.Text = "Package creation completed!"
    }
    catch {
        $txtStatus.Text = $_.Exception.Message
    }

})

# ================================
# Show Window
# ================================
$window.ShowDialog() | Out-Null



# SIG # Begin signature block
# MIIKmwYJKoZIhvcNAQcCoIIKjDCCCogCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQULxm/ZdosIs8KD4orSkoJ7UDw
# Z4OgggfxMIIH7TCCBdWgAwIBAgITfgAqDS38gi3RBcr9PwAAACoNLTANBgkqhkiG
# 9w0BAQsFADBcMRMwEQYKCZImiZPyLGQBGRYDY29tMRcwFQYKCZImiZPyLGQBGRYH
# bXBoYXNpczEUMBIGCgmSJomT8ixkARkWBGNvcnAxFjAUBgNVBAMTDU1waGFzaXNS
# b290Q0EwHhcNMjUwMTI3MTIxNTE1WhcNMjcwMTI3MTIxNTE1WjCBuTETMBEGCgmS
# JomT8ixkARkWA2NvbTEXMBUGCgmSJomT8ixkARkWB21waGFzaXMxFDASBgoJkiaJ
# k/IsZAEZFgRjb3JwMR0wGwYDVQQLExRNcGhhc2lTIEJQTyBTZXJ2aWNlczESMBAG
# A1UECxMJTWFuZ2Fsb3JlMRQwEgYDVQQLEwtNb3JnYW4gR2F0ZTESMBAGA1UECxMJ
# QWxsIFVzZXJzMRYwFAYDVQQDEw1IYXJzaGl0aHJhaiBQMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAxMQa6w0z2RxDuXsD42TVI+y6pNJGSfctL3Wo7FlZ
# 13PDFGwzrJ+MHYrHdXbTDXx9QNwRmp1XEACLBzXvtfkTvptoJXm8S5an710FmIhQ
# X1UaRtMBmxcPHPXYx9srPo/IrspfzjjfzIcA3iyV/kPp/BHc5TAUTwtkaUVDOfsr
# Eo+f0AkJTZY3+4U39rvVSh3Tymo8yett0lFMG+Mo8XoGxXhjmcDYr4WgdPnmRUf7
# 2NprzPYTAr9+CgiAMMlI2oEFVhevReXiYWI8NeBlnDxHF3Wz8vapN82qO/AyCvsu
# 9A8HWsFdKynYlgmqjcEFeq5LTDkqBG40M+mwUwlmrkfdHQIDAQABo4IDSDCCA0Qw
# OwYJKwYBBAGCNxUHBC4wLAYkKwYBBAGCNxUIhMyCH8+9G4LVjRuzxzWGhuksgUCG
# mfcDrJoTAgFkAgEOMBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAb
# BgkrBgEEAYI3FQoEDjAMMAoGCCsGAQUFBwMDMFIGCSsGAQQBgjcZAgRFMEOgQQYK
# KwYBBAGCNxkCAaAzBDFTLTEtNS0yMS0xMDc5NTc2NTIzLTM4NTgxMjM1NjUtMTkw
# OTY3OTkxNS05NTg5MDQyME8GA1UdEQRIMEagKQYKKwYBBAGCNxQCA6AbDBlIYXJz
# aGl0aHJhai5QQG1waGFzaXMuY29tgRlIYXJzaGl0aHJhai5QQG1waGFzaXMuY29t
# MB0GA1UdDgQWBBSkZDx6EbPefW2Ud8IXKJ6tZ3dLPzAfBgNVHSMEGDAWgBQjRSRz
# 1j1XGGn4I9WpMcdUqHHtjTCB2wYDVR0fBIHTMIHQMIHNoIHKoIHHhoHEbGRhcDov
# Ly9DTj1NcGhhc2lzUm9vdENBLENOPVNSVkJBTjA5Q1JBVVZNMSxDTj1DRFAsQ049
# UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJh
# dGlvbixEQz1jb3JwLERDPW1waGFzaXMsREM9Y29tP2NlcnRpZmljYXRlUmV2b2Nh
# dGlvbkxpc3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludDCC
# AQEGCCsGAQUFBwEBBIH0MIHxMIG0BggrBgEFBQcwAoaBp2xkYXA6Ly8vQ049TXBo
# YXNpc1Jvb3RDQSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049
# U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1jb3JwLERDPW1waGFzaXMsREM9
# Y29tP2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9u
# QXV0aG9yaXR5MDgGCCsGAQUFBzABhixodHRwOi8vU1JWQkFOMDlDUkFVVk0xLmNv
# cnAubXBoYXNpcy5jb20vb2NzcDANBgkqhkiG9w0BAQsFAAOCAgEAK86w/bs3xZR1
# wCj+aHRSPYtMjPWaBV1x7FYIRUI4cYUWh8/LSXd+SeecR9ZILHv98WmpHHSCANMm
# AjmLx0GufMz1IS+CuWrMmbtWA81zlYICoCMC8sNGoOHAm16njFwm09Yj0/7lB5OA
# UMbPdy1FoL7FTrOTgnWElBxbZZd4DyEKfC4f+f+6L7cIrFgXiansLLiYy8mTHNUW
# /T4ZipxPYMdcKXkItY94NCsQzccy12xDI8JCd2PFk5p8IVE85yUxP7xT9jc7ZSKg
# AGOuwJ9PDWAFMXQe8DmYyVCrrw0oVn0t7OWcmBsjId8kUjm1kq+lUcMyx+xwhO6q
# 8DbgqFekH6KLJA/fKsSGgxInpqvJzQ9ExTpAuxATrdTZkrlfkIEArqp1DPBMBF7+
# 2pewhdwF3PWqd1zRI1Phmo6lm4ixUST0sVRygV+PT5KuDWVCnrkD39rGn2XcZ5Tk
# /+0eezAMjG4xnXmwja7pu3h0jcDwt7RQoLKKMHc70pFiyKGr5lY5/jWLClFLh3RV
# 7Z/2zKRTRf8NL/uiiS6z9Qv7vuZZ+IqrzB4XxPdCytpKZwoy4vSxBFob6syDLc2r
# FaTctXl3Yg27zp4NYG0+CP+y6fsGw2V6g4zz50wp1SAmWkLL7WK2e3gDzbdUrXq2
# WD+POBA6s8795fJpOk+tkFSY8SENWR0xggIUMIICEAIBATBzMFwxEzARBgoJkiaJ
# k/IsZAEZFgNjb20xFzAVBgoJkiaJk/IsZAEZFgdtcGhhc2lzMRQwEgYKCZImiZPy
# LGQBGRYEY29ycDEWMBQGA1UEAxMNTXBoYXNpc1Jvb3RDQQITfgAqDS38gi3RBcr9
# PwAAACoNLTAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZ
# BgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYB
# BAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQU5IgpDpyxneEcBnZdkKY8f8dKivMwDQYJ
# KoZIhvcNAQEBBQAEggEALDNep7ZNoqGsrdx/0/iESYrJn9vRcgeqSy7iaQvTFY/R
# OKkWRXB5O4+lGwyWhU1Ng6Oyx7R4oQ3tkEJM2oH1+CvfXb6iWy/oi/2JoBA8qW98
# A1OLpRJM9O6yNJB/l8+MxN3hExoz5vra+LTEoCKvuR4NM1bI1KLZ85XsrWqlsP0I
# /wFf7BKdSFWEg58YuApEnMYHEbrpUk+3wPou55rRUQE3WdESGXOo4qKc3GTqED8f
# StA4d+X2ULBYozdt9Ia/MNg8VlbRnC+4cS7W6SGjZpPxIhA+o0W4mfF/CBOQ+hcE
# oL6EH0pZ07+yWjVbDe1krLBBncnaoJmDus8Lf5Ix/Q==
# SIG # End signature block
