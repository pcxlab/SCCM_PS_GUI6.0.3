﻿###############################
function New-PCXCMFolder {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory)]
        [string]$Path,

        [string]$Name
    )

    Write-Verbose "********** Function Begin **********"

    try {
        # -------------------------------
        # Step 1: Detect and extract SiteCode
        # -------------------------------
        $siteCode = $null
        $cleanPath = $null

        if ($Path -match '^[A-Za-z0-9]{3}:\\') {
            # Path includes PSDrive (e.g., PS1:\...)
            $siteCode = $Path.Substring(0,3)
            $cleanPath = $Path.Substring(4)
            Write-Verbose "Detected PSDrive in path: $siteCode"
        }
        else {
            # No PSDrive → use function
            $siteCode = Get-PCXCMSiteCode
            if (-not $siteCode) {
                throw "Failed to retrieve SCCM Site Code."
            }
            $cleanPath = $Path
            Write-Verbose "Using detected SiteCode: $siteCode"
        }

        # -------------------------------
        # Step 2: Ensure ConfigMgr Module + PSDrive
        # -------------------------------
        if (-not (Get-PSDrive -Name $siteCode -ErrorAction SilentlyContinue)) {

            Write-Verbose "PSDrive '$siteCode' not found. Attempting to initialize..."

            $cmModulePath = Join-Path $ENV:SMS_ADMIN_UI_PATH "..\ConfigurationManager.psd1"

            if (-not (Test-Path $cmModulePath)) {
                throw "ConfigurationManager module not found. Install SCCM Console."
            }

            Import-Module $cmModulePath -ErrorAction Stop
            Write-Verbose "ConfigurationManager module loaded."

            try {
                Set-Location "$siteCode`:" -ErrorAction Stop
                Write-Verbose "Connected to site drive: $siteCode"
            }
            catch {
                throw "Failed to switch to PSDrive '$siteCode'. Verify site code."
            }
        }

        $rootPath = "$siteCode`:"
        
        # -------------------------------
        # Step 3: Normalize Path
        # -------------------------------
        $cleanPath = $cleanPath.Trim('\')

        if ([string]::IsNullOrWhiteSpace($cleanPath)) {
            throw "Path cannot be empty."
        }

        $segments = ($cleanPath -split '\\') | Where-Object { $_ }

        Write-Verbose "Normalized Path: $cleanPath"
        Write-Verbose "Segments: $($segments -join ' -> ')"

        # -------------------------------
        # Step 4: Create Path Step-by-Step
        # -------------------------------
        $currentPath = $rootPath

        foreach ($folder in $segments) {
            $nextPath = Join-Path $currentPath $folder

            if (-not (Test-Path $nextPath)) {
                if ($PSCmdlet.ShouldProcess($nextPath, "Create folder")) {
                    New-Item -Path $currentPath -Name $folder -ItemType Directory -ErrorAction Stop
                    Write-Verbose "Created: $nextPath"
                }
            }
            else {
                Write-Verbose "Exists: $nextPath"
            }

            $currentPath = $nextPath
        }

        # -------------------------------
        # Step 5: Handle Optional Name
        # -------------------------------
        if ($Name) {
            if ([string]::IsNullOrWhiteSpace($Name)) {
                throw "Folder name cannot be empty."
            }

            $finalPath = Join-Path $currentPath $Name

            if (-not (Test-Path $finalPath)) {
                if ($PSCmdlet.ShouldProcess($finalPath, "Create folder")) {
                    New-Item -Path $currentPath -Name $Name -ItemType Directory -ErrorAction Stop
                    Write-Verbose "Created final folder: $finalPath"
                }
            }
            else {
                Write-Verbose "Final folder already exists: $finalPath"
            }
        }
        else {
            # No Name → full path already created
            $finalPath = $currentPath
            Write-Verbose "No child name provided. Full path ensured."
        }

        # -------------------------------
        # Step 6: Return Result
        # -------------------------------
        return [PSCustomObject]@{
            Success  = $true
            Path     = $finalPath
            SiteCode = $siteCode
        }
    }
    catch {
        Write-Error "Failed: $($_.Exception.Message)"

        return [PSCustomObject]@{
            Success = $false
            Error   = $_.Exception.Message
        }
    }
}
#############################################################
# Example usage 
<#
New-PCXCMFolder -Path "\DeviceCollection\RootFolder\" -Name "Child"
New-PCXCMFolder -Path "DeviceCollection\RootFolder" -Name "Child"
New-PCXCMFolder -Path "\DeviceCollection\RootFolder" -Name "Child"
New-PCXCMFolder -Path "\DeviceCollection\RootFolder" 

#New-PCXCMFolder -Path "\DeviceCollection\RootFolder\SubFoler" -Name "Child" -AutoCreatePath
#New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFoler" -Name "Child" -AutoCreatePath
#New-PCXCMFolder -Path "DeviceCollection\RootFolder\" -Name "Child" -AutoCreatePath
#New-PCXCMFolder -Path "\DeviceCollection\" -Name "Child" -AutoCreatePath
#New-PCXCMFolder -Path "\DeviceCollection\AAA" -Name "Child"
#>

<#
This can work on all below root folders

New-PCXCMFolder -Path "\Application\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\BootImage\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\ConfigurationBaseline\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\ConfigurationItem\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\DeviceCollection\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\Driver\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\DriverPackage\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\OperatingSystemImage\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\OperatingSystemInstaller\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\Package\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\Query\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\SoftwareMetering\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\SoftwareUpdate\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\TaskSequence\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\UserCollection\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\UserStateMigration\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\VirtualHardDisk\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\DeploymentPackage\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\SoftwareUpdateGroup\RootFolder\" -Name "Child"

New-PCXCMFolder -Path "\AutoDeploymentRule\RootFolder\" -Name "Child"

#>

#############################################################
# Reproducing command 
<#
Remove-PCXCMFolder "PS1:\DeviceCollection\RootFolder\Test"
Remove-PCXCMFolder "PS1:\DeviceCollection\RootFolder"
Remove-PCXCMFolder "PS1:\DeviceCollection\RootFolder\SubFolder"
Get-ChildItem -path "PS1:\DeviceCollection\RootFolder"
#>

#############################################################
#Remove-Module PCXCMModule
#Remove-Module PCXCMModule -Force
#############################################################
<#
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder" -Name "Child"
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\" -Name "Child"
New-PCXCMFolder -Path "\DeviceCollection\RootFolder\SubFolder\" -Name "Child"
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\"
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\Tree"
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\Tree"
#>

# Test Cases
<#

#1. Standard PSDrive paths
# Normal path with Name
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder" -Name "Child"

# Trailing backslash
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\" -Name "Child"

# Nested folder creation
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\Tree" -Name "Leaf"

#2. Paths without PSDrive (function should auto-detect SiteCode)
# Relative path, no PSDrive prefix
New-PCXCMFolder -Path "\DeviceCollection\RootFolder\SubFolder" -Name "Child"

# Nested path without PSDrive
New-PCXCMFolder -Path "DeviceCollection\RootFolder\SubFolder\Tree" -Name "Leaf"

#3. Paths without -Name (full path creation)
# Only ensure full path exists
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\Tree"

# Without trailing backslash
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\Tree2"

#4. Edge cases / input validation
# Empty path (should fail)
New-PCXCMFolder -Path "" -Name "Child"

# Name is whitespace (should fail)
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder" -Name "   "

# Path with multiple consecutive backslashes
New-PCXCMFolder -Path "PS1:\DeviceCollection\\RootFolder\\SubFolder" -Name "Child"

#5. Existing folders
# Path and Name already exist (should not throw an error)
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder" -Name "Child"

# Existing nested folders (should skip creation and report verbose)
New-PCXCMFolder -Path "PS1:\DeviceCollection\RootFolder\SubFolder\Tree" -Name "Leaf"

#6. Invalid PSDrive
# PSDrive that does not exist
New-PCXCMFolder -Path "PX1:\DeviceCollection\RootFolder" -Name "Child"

#>


# Run all cases

<#

# -------------------------------
# Test harness for New-PCXCMFolder
# -------------------------------

# Define all test cases as objects
$testCases = @(
    # Standard PSDrive paths
    @{ Path = "PS1:\DeviceCollection\RootFolder\SubFolder"; Name = "Child" },
    @{ Path = "PS1:\DeviceCollection\RootFolder\SubFolder\"; Name = "Child" },
    @{ Path = "PS1:\DeviceCollection\RootFolder\SubFolder\Tree"; Name = "Leaf" },

    # Paths without PSDrive
    @{ Path = "\DeviceCollection\RootFolder\SubFolder"; Name = "Child" },
    @{ Path = "DeviceCollection\RootFolder\SubFolder\Tree"; Name = "Leaf" },

    # Paths without Name
    @{ Path = "PS1:\DeviceCollection\RootFolder\SubFolder\Tree"; Name = $null },
    @{ Path = "PS1:\DeviceCollection\RootFolder\SubFolder\Tree2"; Name = $null },

    # Edge cases
    @{ Path = ""; Name = "Child" },                            # Should fail
    @{ Path = "PS1:\DeviceCollection\RootFolder\SubFolder"; Name = "   " }, # Should fail
    @{ Path = "PS1:\DeviceCollection\\RootFolder\\SubFolder"; Name = "Child" },

    # Existing folders
    @{ Path = "PS1:\DeviceCollection\RootFolder\SubFolder"; Name = "Child" },
    @{ Path = "PS1:\DeviceCollection\RootFolder\SubFolder\Tree"; Name = "Leaf" },

    # Invalid PSDrive
    @{ Path = "PX1:\DeviceCollection\RootFolder"; Name = "Child" }
)

# Array to store results
$results = @()

foreach ($test in $testCases) {
    try {
        Write-Host "Running test: Path='$($test.Path)' Name='$($test.Name)'" -ForegroundColor Cyan

        # Run the function
        $output = if ($test.Name) {
            New-PCXCMFolder -Path $test.Path -Name $test.Name -Verbose -WhatIf
        } else {
            New-PCXCMFolder -Path $test.Path -Verbose -WhatIf
        }

        # Store result
        $results += [PSCustomObject]@{
            Path     = $test.Path
            Name     = $test.Name
            Success  = $output.Success
            Message  = if ($output.Success) { "Folder creation simulated/passed" } else { $output.Error }
        }
    }
    catch {
        $results += [PSCustomObject]@{
            Path     = $test.Path
            Name     = $test.Name
            Success  = $false
            Message  = $_.Exception.Message
        }
    }
}

# Display results in table
$results | Format-Table -AutoSize

<#
✅ Features of this test harness:
Runs all test cases automatically.
Uses -WhatIf so no real SCCM folders are created—safe to run.
Captures success/failure and error messages.
Prints a clean table summary at the end.
Handles both -Name provided and not provided.
#>

#>
<#

$results
$results.Count
$results[8]

#>

# SIG # Begin signature block
# MIIKmwYJKoZIhvcNAQcCoIIKjDCCCogCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUbmJUBr0uGUWe8OeWnoiebgrT
# cwygggfxMIIH7TCCBdWgAwIBAgITfgAqDS38gi3RBcr9PwAAACoNLTANBgkqhkiG
# 9w0BAQsFADBcMRMwEQYKCZImiZPyLGQBGRYDY29tMRcwFQYKCZImiZPyLGQBGRYH
# bXBoYXNpczEUMBIGCgmSJomT8ixkARkWBGNvcnAxFjAUBgNVBAMTDU1waGFzaXNS
# b290Q0EwHhcNMjUwMTI3MTIxNTE1WhcNMjcwMTI3MTIxNTE1WjCBuTETMBEGCgmS
# JomT8ixkARkWA2NvbTEXMBUGCgmSJomT8ixkARkWB21waGFzaXMxFDASBgoJkiaJ
# k/IsZAEZFgRjb3JwMR0wGwYDVQQLExRNcGhhc2lTIEJQTyBTZXJ2aWNlczESMBAG
# A1UECxMJTWFuZ2Fsb3JlMRQwEgYDVQQLEwtNb3JnYW4gR2F0ZTESMBAGA1UECxMJ
# QWxsIFVzZXJzMRYwFAYDVQQDEw1IYXJzaGl0aHJhaiBQMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAxMQa6w0z2RxDuXsD42TVI+y6pNJGSfctL3Wo7FlZ
# 13PDFGwzrJ+MHYrHdXbTDXx9QNwRmp1XEACLBzXvtfkTvptoJXm8S5an710FmIhQ
# X1UaRtMBmxcPHPXYx9srPo/IrspfzjjfzIcA3iyV/kPp/BHc5TAUTwtkaUVDOfsr
# Eo+f0AkJTZY3+4U39rvVSh3Tymo8yett0lFMG+Mo8XoGxXhjmcDYr4WgdPnmRUf7
# 2NprzPYTAr9+CgiAMMlI2oEFVhevReXiYWI8NeBlnDxHF3Wz8vapN82qO/AyCvsu
# 9A8HWsFdKynYlgmqjcEFeq5LTDkqBG40M+mwUwlmrkfdHQIDAQABo4IDSDCCA0Qw
# OwYJKwYBBAGCNxUHBC4wLAYkKwYBBAGCNxUIhMyCH8+9G4LVjRuzxzWGhuksgUCG
# mfcDrJoTAgFkAgEOMBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAb
# BgkrBgEEAYI3FQoEDjAMMAoGCCsGAQUFBwMDMFIGCSsGAQQBgjcZAgRFMEOgQQYK
# KwYBBAGCNxkCAaAzBDFTLTEtNS0yMS0xMDc5NTc2NTIzLTM4NTgxMjM1NjUtMTkw
# OTY3OTkxNS05NTg5MDQyME8GA1UdEQRIMEagKQYKKwYBBAGCNxQCA6AbDBlIYXJz
# aGl0aHJhai5QQG1waGFzaXMuY29tgRlIYXJzaGl0aHJhai5QQG1waGFzaXMuY29t
# MB0GA1UdDgQWBBSkZDx6EbPefW2Ud8IXKJ6tZ3dLPzAfBgNVHSMEGDAWgBQjRSRz
# 1j1XGGn4I9WpMcdUqHHtjTCB2wYDVR0fBIHTMIHQMIHNoIHKoIHHhoHEbGRhcDov
# Ly9DTj1NcGhhc2lzUm9vdENBLENOPVNSVkJBTjA5Q1JBVVZNMSxDTj1DRFAsQ049
# UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJh
# dGlvbixEQz1jb3JwLERDPW1waGFzaXMsREM9Y29tP2NlcnRpZmljYXRlUmV2b2Nh
# dGlvbkxpc3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludDCC
# AQEGCCsGAQUFBwEBBIH0MIHxMIG0BggrBgEFBQcwAoaBp2xkYXA6Ly8vQ049TXBo
# YXNpc1Jvb3RDQSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049
# U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1jb3JwLERDPW1waGFzaXMsREM9
# Y29tP2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9u
# QXV0aG9yaXR5MDgGCCsGAQUFBzABhixodHRwOi8vU1JWQkFOMDlDUkFVVk0xLmNv
# cnAubXBoYXNpcy5jb20vb2NzcDANBgkqhkiG9w0BAQsFAAOCAgEAK86w/bs3xZR1
# wCj+aHRSPYtMjPWaBV1x7FYIRUI4cYUWh8/LSXd+SeecR9ZILHv98WmpHHSCANMm
# AjmLx0GufMz1IS+CuWrMmbtWA81zlYICoCMC8sNGoOHAm16njFwm09Yj0/7lB5OA
# UMbPdy1FoL7FTrOTgnWElBxbZZd4DyEKfC4f+f+6L7cIrFgXiansLLiYy8mTHNUW
# /T4ZipxPYMdcKXkItY94NCsQzccy12xDI8JCd2PFk5p8IVE85yUxP7xT9jc7ZSKg
# AGOuwJ9PDWAFMXQe8DmYyVCrrw0oVn0t7OWcmBsjId8kUjm1kq+lUcMyx+xwhO6q
# 8DbgqFekH6KLJA/fKsSGgxInpqvJzQ9ExTpAuxATrdTZkrlfkIEArqp1DPBMBF7+
# 2pewhdwF3PWqd1zRI1Phmo6lm4ixUST0sVRygV+PT5KuDWVCnrkD39rGn2XcZ5Tk
# /+0eezAMjG4xnXmwja7pu3h0jcDwt7RQoLKKMHc70pFiyKGr5lY5/jWLClFLh3RV
# 7Z/2zKRTRf8NL/uiiS6z9Qv7vuZZ+IqrzB4XxPdCytpKZwoy4vSxBFob6syDLc2r
# FaTctXl3Yg27zp4NYG0+CP+y6fsGw2V6g4zz50wp1SAmWkLL7WK2e3gDzbdUrXq2
# WD+POBA6s8795fJpOk+tkFSY8SENWR0xggIUMIICEAIBATBzMFwxEzARBgoJkiaJ
# k/IsZAEZFgNjb20xFzAVBgoJkiaJk/IsZAEZFgdtcGhhc2lzMRQwEgYKCZImiZPy
# LGQBGRYEY29ycDEWMBQGA1UEAxMNTXBoYXNpc1Jvb3RDQQITfgAqDS38gi3RBcr9
# PwAAACoNLTAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZ
# BgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYB
# BAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUGtV9buGYZOuAvZtWsy2OUH7UfjEwDQYJ
# KoZIhvcNAQEBBQAEggEAeXrZKc+6QMp+WZmmx76MmJ2ejsc1/hg9l5hziszLFg+S
# glSxITvtR7F75T6Ms2LHlwjyXK+AGNA6f8l9Pfh4qw3iJkaVH3XYk1/nHYEM2lAr
# WCK/CGk5Ca4bXA9/mfXwZhkD/AZO634+YeBi7Ti+NkEU74qqRH98pNAi2c32bTMm
# QtZMvH0jRIGG3W9f7ShVhB/OUHMU1aQ0y1LlCOyBIl+/0C3wggGBmHszreGpAUAG
# hGHfI+7soSBYfcQ9BZrKmW3wXzsLWuWORO3iFt5I17R7fTb58idnxlNcGLh7QMM1
# 8WE68UqOIlrM5JolmJtPvcgNXzML7JItqFL3NSoAiw==
# SIG # End signature block
