﻿function Create-Package { 
    param(
        [parameter(mandatory=$false)] [string] $Language = "EN-US",
        [parameter(mandatory=$true)] [string] $Path,
        [parameter(mandatory=$false)] [string] $LimitingCollectionName = "ALL Systems",
        [parameter(mandatory=$false)] [string] $DistributionPoinGroupName = "Mangalore Distribution point",
        [parameter(mandatory=$false)] [datetime] $DeadlineTime
    )

    Clear-Host

    Write-Host "DP Group NAme is $DistributionPoinGroupName"

    <# FOR TEST ONLY###########################################################
    $Path = "\\192.168.25.214\Package_Source\Applications\Google\Chrome\Google_Chrome_145.0.7632.46"
    $Language = "EN-US"
    $LimitingCollectionName = "ALL Systems"
    $DistributionPoinGroupName = "ALL Mangalore Group"
    # FOR TEST ONLY########################################################### #>

    <#
    $Path = "\\172.16.100.56\Package_Source\Applications\Google\Chrome\Google_Chrome_500.0.7499.41"
    $Language = "EN-US"
    $LimitingCollectionName = "ALL Systems"
    # $DistributionPoinGroupName = "Mphasis & DR - Distribution Point of Application Pacakge Deployment"
    $DistributionPoinGroupName = "Mangalore Distribution point"
    #>

    # ---------------------------------------
    # Extract package details from given path
    # ---------------------------------------
    $pathSPlit = $Path -split "\\"

    $Packagename = $pathSPlit[-1]
    $Company     = $pathSPlit[-3]
    $Product     = $pathSPlit[-2]

    Write-Host "Package name: $Packagename" -ForegroundColor Yellow
    Write-Host "Company/Manufacturer: $Company" -ForegroundColor Yellow
    Write-Host "Product/Application: $Product" -ForegroundColor Yellow

    # ---------------------------------------
    # Extract version from package name
    # ---------------------------------------
    $VersionSPlit = $Packagename -split "_"
    $Version      = $VersionSPlit[-1]

    Write-Host "Version: $Version" -ForegroundColor Green

    # ---------------------------------------
    # Generate program names
    # ---------------------------------------
    $ProgramName1 = $Packagename + "[AVAILABLE]"
    $ProgramName2 = $Packagename + "[INSTALL]"
    $ProgramName3 = $Packagename + "[UNINSTALL]"

    Write-Host "ProgramName1: $ProgramName1" -ForegroundColor Green
    Write-Host "ProgramName2: $ProgramName2" -ForegroundColor Green
    Write-Host "ProgramName3: $ProgramName3" -ForegroundColor Green

    # ---------------------------------------
    # Generate collection names
    # ---------------------------------------
    $CollectionName1 = $Packagename + "[AVAILABLE]"
    $CollectionName2 = $Packagename + "[INSTALL]"
    $CollectionName3 = $Packagename + "[UNINSTALL]"
    $CollectionName4 = $Packagename + "[EXCEPTION]"

    Write-Host "CollectionName1: $CollectionName1" -ForegroundColor Green
    Write-Host "CollectionName2: $CollectionName2" -ForegroundColor Green
    Write-Host "CollectionName3: $CollectionName3" -ForegroundColor Green
    Write-Host "CollectionName4: $CollectionName4" -ForegroundColor Green

    # ---------------------------------------
    # Create SCCM package
    # ---------------------------------------
    New-CMPackage -Name $Packagename -Manufacturer $Company -Version $Version -Language $Language -Path $Path
    Write-Host "Package created" -ForegroundColor Green
                                                                     
    # ---------------------------------------
    # Create programs (Available / Install / Uninstall)
    # ---------------------------------------
    New-CMProgram -PackageName $Packagename -StandardProgramName $ProgramName1 -CommandLine "install.exe" -RunMode RunWithAdministrativeRights -ProgramRunType WhetherOrNotUserIsLoggedOn
    New-CMProgram -PackageName $Packagename -StandardProgramName $ProgramName2 -CommandLine "install.bat" -RunMode RunWithAdministrativeRights -ProgramRunType WhetherOrNotUserIsLoggedOn
    New-CMProgram -PackageName $Packagename -StandardProgramName $ProgramName3 -CommandLine "uninstall.bat" -RunMode RunWithAdministrativeRights -ProgramRunType WhetherOrNotUserIsLoggedOn

    Write-Host "Programs created" -ForegroundColor Green
                 
    # ---------------------------------------
    # Create device collections
    # ---------------------------------------
    #New-CMDeviceCollection -Name $CollectionName1 -LimitingCollectionName $LimitingCollectionName
    #New-CMDeviceCollection -Name $CollectionName2 -LimitingCollectionName $LimitingCollectionName
    #New-CMDeviceCollection -Name $CollectionName3 -LimitingCollectionName $LimitingCollectionName
    #New-CMDeviceCollection -Name $CollectionName4 -LimitingCollectionName $LimitingCollectionName

    Write-Host "Collections created" -ForegroundColor Green
     
    # ---------------------------------------
    # Distribute content to DP group
    # ---------------------------------------
    Write-Host "now dp update starts : $DistributionPoinGroupName" -ForegroundColor Yellow
    Start-CMContentDistribution -PackageName $Packagename -DistributionPointGroupName $DistributionPoinGroupName
    Write-Host "Distribution Point Group updated" -ForegroundColor Green
          
    # ---------------------------------------
    # Deploy programs to collections
    # ---------------------------------------
    $ProgramComment = $Packagename + " Program"
    

    New-CMPackageDeployment -StandardProgram -PackageName $Packagename -CollectionName $CollectionName1 -Comment "$ProgramComment" -DeployPurpose Available -ProgramName $ProgramName1
    New-CMPackageDeployment -StandardProgram -PackageName $Packagename -CollectionName $CollectionName2 -Comment "$ProgramComment" -DeployPurpose Available -ProgramName $ProgramName2
    #New-CMPackageDeployment -StandardProgram -PackageName $Packagename -CollectionName $CollectionName3 -Comment "$ProgramComment" -DeployPurpose Required -ProgramName $ProgramName3


    # Create deadline schedule (default: today 8 PM + 10 days)
    $DeadlineTime        = (Get-Date -Hour 20 -Minute 0 -Second 0).AddDays(30)
    $NewScheduleDeadline = New-CMSchedule -Start $DeadlineTime -Nonrecurring
    
    New-CMPackageDeployment -StandardProgram -PackageName $Packagename -ProgramName $ProgramName3 -DeployPurpose Required -CollectionName $CollectionName3 -Schedule $NewScheduleDeadline   

    Write-Host "Program deployed to collections" -ForegroundColor Green

    $siteCode = Get-PCXCMSiteCode
    $CollectionFolder =  "\DeviceCollection\Mphasis Application Deployment\$Company\$Product\$Packagename"
    $CollectionFolderPath = "$siteCode" + ":$CollectionFolder"

    #$CollectionFolderPath =  "\DeviceCollection\Mphasis Application Deployment\$Company\$Product\$Packagename\"
    
    New-PCXCMFolder -Path $CollectionFolder

    # Move the collection to the specified folder
    $CollectionObject = Get-CMDeviceCollection -Name $CollectionName1 # Available 
    Move-CMObject -FolderPath $CollectionFolderPath -InputObject $CollectionObject
    Write-Host "Collection '$CollectionName' is Moved to '$CollectionFolderPath'"

    $CollectionObject = Get-CMDeviceCollection -Name $CollectionName2 # Install
    Move-CMObject -FolderPath $CollectionFolderPath -InputObject $CollectionObject
    Write-Host "Collection '$CollectionName' is Moved to '$CollectionFolderPath'"

    $CollectionObject = Get-CMDeviceCollection -Name $CollectionName3 # Uninstall
    Move-CMObject -FolderPath $CollectionFolderPath -InputObject $CollectionObject
    Write-Host "Collection '$CollectionName' is Moved to '$CollectionFolderPath'"

    $CollectionObject = Get-CMDeviceCollection -Name $CollectionName4 # Exception
    Move-CMObject -FolderPath $CollectionFolderPath -InputObject $CollectionObject
    Write-Host "Collection '$CollectionName' is Moved to '$CollectionFolderPath'"

    Add-CMDeviceCollectionIncludeMembershipRule -CollectionName $CollectionName4 -IncludeCollectionName $CollectionName3
    Add-CMDeviceCollectionExcludeMembershipRule -CollectionName $CollectionName2 -ExcludeCollectionName $CollectionName4

    $siteCode = Get-PCXCMSiteCode
    $PackageFolder = "\Package\Application Installation\$Company\$Product\$Packagename"
    $PackageFolderFolderPath = "$siteCode" + ":$PackageFolder"

    New-PCXCMFolder -Path $PackageFolder
    $PackageObject = Get-CMPackage -Name $Packagename # Exception
    Move-CMObject -FolderPath $PackageFolderFolderPath -InputObject $PackageObject
    Write-Host "Pacakge '$Packagename' is Moved to '$PackageFolderFolderPath'"

}

# ---------------------------------------
# Example usage
# ---------------------------------------
#Create-Package -Path "\\192.168.25.214\Package_source\Applications\Tim Kosse\FileZilla\Tim Kosse_FileZilla_3.69.6.0"

#Create-Package -Path "\\192.168.25.214\Package_Source\Applications\Google\Chrome\Google_Chrome_145.0.7632.46"




# SIG # Begin signature block
# MIIKmwYJKoZIhvcNAQcCoIIKjDCCCogCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUJcA9c+158jD5ZdNtn/FpNhDr
# KDygggfxMIIH7TCCBdWgAwIBAgITfgAqDS38gi3RBcr9PwAAACoNLTANBgkqhkiG
# 9w0BAQsFADBcMRMwEQYKCZImiZPyLGQBGRYDY29tMRcwFQYKCZImiZPyLGQBGRYH
# bXBoYXNpczEUMBIGCgmSJomT8ixkARkWBGNvcnAxFjAUBgNVBAMTDU1waGFzaXNS
# b290Q0EwHhcNMjUwMTI3MTIxNTE1WhcNMjcwMTI3MTIxNTE1WjCBuTETMBEGCgmS
# JomT8ixkARkWA2NvbTEXMBUGCgmSJomT8ixkARkWB21waGFzaXMxFDASBgoJkiaJ
# k/IsZAEZFgRjb3JwMR0wGwYDVQQLExRNcGhhc2lTIEJQTyBTZXJ2aWNlczESMBAG
# A1UECxMJTWFuZ2Fsb3JlMRQwEgYDVQQLEwtNb3JnYW4gR2F0ZTESMBAGA1UECxMJ
# QWxsIFVzZXJzMRYwFAYDVQQDEw1IYXJzaGl0aHJhaiBQMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAxMQa6w0z2RxDuXsD42TVI+y6pNJGSfctL3Wo7FlZ
# 13PDFGwzrJ+MHYrHdXbTDXx9QNwRmp1XEACLBzXvtfkTvptoJXm8S5an710FmIhQ
# X1UaRtMBmxcPHPXYx9srPo/IrspfzjjfzIcA3iyV/kPp/BHc5TAUTwtkaUVDOfsr
# Eo+f0AkJTZY3+4U39rvVSh3Tymo8yett0lFMG+Mo8XoGxXhjmcDYr4WgdPnmRUf7
# 2NprzPYTAr9+CgiAMMlI2oEFVhevReXiYWI8NeBlnDxHF3Wz8vapN82qO/AyCvsu
# 9A8HWsFdKynYlgmqjcEFeq5LTDkqBG40M+mwUwlmrkfdHQIDAQABo4IDSDCCA0Qw
# OwYJKwYBBAGCNxUHBC4wLAYkKwYBBAGCNxUIhMyCH8+9G4LVjRuzxzWGhuksgUCG
# mfcDrJoTAgFkAgEOMBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAb
# BgkrBgEEAYI3FQoEDjAMMAoGCCsGAQUFBwMDMFIGCSsGAQQBgjcZAgRFMEOgQQYK
# KwYBBAGCNxkCAaAzBDFTLTEtNS0yMS0xMDc5NTc2NTIzLTM4NTgxMjM1NjUtMTkw
# OTY3OTkxNS05NTg5MDQyME8GA1UdEQRIMEagKQYKKwYBBAGCNxQCA6AbDBlIYXJz
# aGl0aHJhai5QQG1waGFzaXMuY29tgRlIYXJzaGl0aHJhai5QQG1waGFzaXMuY29t
# MB0GA1UdDgQWBBSkZDx6EbPefW2Ud8IXKJ6tZ3dLPzAfBgNVHSMEGDAWgBQjRSRz
# 1j1XGGn4I9WpMcdUqHHtjTCB2wYDVR0fBIHTMIHQMIHNoIHKoIHHhoHEbGRhcDov
# Ly9DTj1NcGhhc2lzUm9vdENBLENOPVNSVkJBTjA5Q1JBVVZNMSxDTj1DRFAsQ049
# UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJh
# dGlvbixEQz1jb3JwLERDPW1waGFzaXMsREM9Y29tP2NlcnRpZmljYXRlUmV2b2Nh
# dGlvbkxpc3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludDCC
# AQEGCCsGAQUFBwEBBIH0MIHxMIG0BggrBgEFBQcwAoaBp2xkYXA6Ly8vQ049TXBo
# YXNpc1Jvb3RDQSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049
# U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1jb3JwLERDPW1waGFzaXMsREM9
# Y29tP2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9u
# QXV0aG9yaXR5MDgGCCsGAQUFBzABhixodHRwOi8vU1JWQkFOMDlDUkFVVk0xLmNv
# cnAubXBoYXNpcy5jb20vb2NzcDANBgkqhkiG9w0BAQsFAAOCAgEAK86w/bs3xZR1
# wCj+aHRSPYtMjPWaBV1x7FYIRUI4cYUWh8/LSXd+SeecR9ZILHv98WmpHHSCANMm
# AjmLx0GufMz1IS+CuWrMmbtWA81zlYICoCMC8sNGoOHAm16njFwm09Yj0/7lB5OA
# UMbPdy1FoL7FTrOTgnWElBxbZZd4DyEKfC4f+f+6L7cIrFgXiansLLiYy8mTHNUW
# /T4ZipxPYMdcKXkItY94NCsQzccy12xDI8JCd2PFk5p8IVE85yUxP7xT9jc7ZSKg
# AGOuwJ9PDWAFMXQe8DmYyVCrrw0oVn0t7OWcmBsjId8kUjm1kq+lUcMyx+xwhO6q
# 8DbgqFekH6KLJA/fKsSGgxInpqvJzQ9ExTpAuxATrdTZkrlfkIEArqp1DPBMBF7+
# 2pewhdwF3PWqd1zRI1Phmo6lm4ixUST0sVRygV+PT5KuDWVCnrkD39rGn2XcZ5Tk
# /+0eezAMjG4xnXmwja7pu3h0jcDwt7RQoLKKMHc70pFiyKGr5lY5/jWLClFLh3RV
# 7Z/2zKRTRf8NL/uiiS6z9Qv7vuZZ+IqrzB4XxPdCytpKZwoy4vSxBFob6syDLc2r
# FaTctXl3Yg27zp4NYG0+CP+y6fsGw2V6g4zz50wp1SAmWkLL7WK2e3gDzbdUrXq2
# WD+POBA6s8795fJpOk+tkFSY8SENWR0xggIUMIICEAIBATBzMFwxEzARBgoJkiaJ
# k/IsZAEZFgNjb20xFzAVBgoJkiaJk/IsZAEZFgdtcGhhc2lzMRQwEgYKCZImiZPy
# LGQBGRYEY29ycDEWMBQGA1UEAxMNTXBoYXNpc1Jvb3RDQQITfgAqDS38gi3RBcr9
# PwAAACoNLTAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZ
# BgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYB
# BAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQURmta4WjM2sEsbYivZpmlQiglLQowDQYJ
# KoZIhvcNAQEBBQAEggEALREEcuiUCeFDFctMi4pSaftjxNr61a3JiLuJqzIeLRxL
# 2i3RLxrlfHDhlHpKvm/bKzd5vM1op4XXpgpbJjmEB1zQQuD2tUHOYatKo1H1gGAH
# ncJ2kbKchDIRK5InxaLDC6zWQhFqGQgqRHKJT/A6hpeZ4gk3ZYuatLkQImb3tOcx
# m3QoLYyfh/K7mI2ng5ADT+xENrKlvmfNQYzttOW+hu/ayPRyF4MH4eHHAzg2jMwz
# fVfaPoDnACoE9xqxAcFsCjC5mjUBCa5ITe57ntigx67g2jqipZM3zZ4b3Mb4vYrW
# yLnNdt8EcUGxSEYmHSO1rxzb135UeRpSwPIWYSgUNw==
# SIG # End signature block
