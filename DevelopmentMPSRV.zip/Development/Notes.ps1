﻿cd c:
Remove-Module MySCCMModule -Force
Get-YearMonth

cd "F:\Development\MySCCMModule"
Import-Module .\MySCCMModule.psd1 -Force
Get-Variable ColSuccess, ColError, ColInform


cd c:
Remove-Module PCXCMModule -Force
Get-YearMonth

cd "F:\Development\PCXCMModule"
Import-Module .\PCXCMModule.psd1 -Force
Get-Variable ColSuccess, ColError, ColInform

$yearMonth = Get-YearMonth
Write-Output "Current Year and Month: $yearMonth"
$today = Get-Date
$abbreviatedMonth = Get-AbbreviatedMonthName -date $today
Write-Host "Abbreviated Month Name: $abbreviatedMonth"

# Call the function and assign the result to a variable
$SiteCode = Get-SCCMSiteCode

# Check if the site code was retrieved successfully
if ($SiteCode -ne $null) {
    Write-Output "Assigned SCCM Site Code is: $SiteCode"
} else {
    Write-Output "Failed to retrieve SCCM Site Code."
    exit 0
}


# Call the function and assign the result to a variable
$ProviderMachineName = Get-SystemFQDN

# Check if the FQDN was retrieved successfully
if ($ProviderMachineName -ne $null) {
    Write-Output "Assigned FQDN is: $ProviderMachineName"
} else {
    Write-Output "Failed to retrieve FQDN."
    exit 0
}


Initialize-SCCMEnvironment

#############################################################

################################

Initialize-SCCMEnvironment

Get-SCCMSiteCode

Set-Location "$($SiteCode):\"



Get-SystemFQDN

Remove-Module MySCCMModule -Force
Import-Module .\MySCCMModule.psd1 -Force




Create-Folder -Path "DeviceCollection\Test Collections\Deployments\ABV" -Name "Three1" -VerboseOutput\

Create-Folder -Path "DeviceCollection\Test Collections\Deployments\ABV\cas\we\longpath\missin" -Name "Three1" 


 
Create-Folder -Path "DeviceCollection\Test Collections\Deployments\" -Name "ThreeFol1"
Create-Folder -Path "DeviceCollection\Test Collections\Deployments" -Name "ThreeFol1"
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder" -Name "Xyz"
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder\" -Name "Xyz" -AutoCreatePath
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder" -Name "Xyz" -AutoCreatePath


Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder" -Name "Xyzz"
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder\" -Name "Xyzz"
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder\" -Name "Xyzza"

Create-Folder -Path "DeviceCollection\Test Collections\Deep\Sub\Folder" -Name "MyFolder" -AutoCreatePath -Verbose
Create-Folder -Path "DeviceCollection\Test Collections\Missing" -Name "AnotherFolder"


# Works cleanly
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder\" -Name "Xyzza"
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder" -Name "Xyzza"

# Also works now — trailing backslash removed internally
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder\b\" -Name "Xyzza" -AutoCreatePath
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder\b\c\d" -Name "Xyzza" -AutoCreatePath

Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder\" -Name "Xyzzb"
Create-Folder -Path "DeviceCollection\Test Collections\Missing\Subfolder" -Name "Xyzzb"


######################################


Create-And-MoveCMCollection -CollectionName "SMS_Collection_05Percent_Set_01" -LimitingCollection "All Windows Workstation or Professional Systems" -FolderPath "DeviceCollection\Reusable Collections\5 Percent Sets"
$Percent05_Set1_DEC_1to13_HEX_01to0D = 'select *  from  SMS_R_System where SMS_R_System.SMSUniqueIdentifier like "%01" or SMS_R_System.SMSUniqueIdentifier like "%02" or SMS_R_System.SMSUniqueIdentifier like "%03" or SMS_R_System.SMSUniqueIdentifier like "%04" or SMS_R_System.SMSUniqueIdentifier like "%05" or SMS_R_System.SMSUniqueIdentifier like "%06" or SMS_R_System.SMSUniqueIdentifier like "%07" or SMS_R_System.SMSUniqueIdentifier like "%08" or SMS_R_System.SMSUniqueIdentifier like "%09" or SMS_R_System.SMSUniqueIdentifier like "%0A" or SMS_R_System.SMSUniqueIdentifier like "%0B" or SMS_R_System.SMSUniqueIdentifier like "%0C" or SMS_R_System.SMSUniqueIdentifier like "%0D"'
Add-CMDeviceCollectionQueryMembershipRuleWithQuery -CollectionName "SMS_Collection_05Percent_Set_01" -QueryExpression $Percent05_Set1_DEC_1to13_HEX_01to0D -RuleName "Percent05_Set1_DEC_1to13_HEX_01to0D"


Get-Command -Module MySCCMModule | Where-Object {
    $_.Name -match '[#\(\)\{\}\[\]&/\\\$^;:"''<>|?@`*%=~]' -or
    ($_.Name -split '-').Count -gt 2
} | Select-Object Name


New-CMDeviceCollectionWithPath	

cd c:
Remove-Module MySCCMModule -Force
Get-YearMonth
cd "F:\Development\MySCCMModule"
Import-Module .\MySCCMModule.psd1 -Force
Get-YearMonth
Get-Variable ColSuccess, ColError, ColInform

Get-YearMonth


######################################################

Connect-CMSite


# Set up variables
$yearMonth = Get-YearMonth
$SiteCode = Get-SCCMSiteCode
$ProviderMachineName = Get-SystemFQDN

# Initialize SCCM drive connection
Initialize-SCCMEnvironment -SiteCode $SiteCode -ProviderMachineName $ProviderMachineName

# Create folder under the SCCM Console
Create-Folder -Path "$($SiteCode):\DeviceCollection\Security Management Services\Deployments" -Name "TESTING"
Create-Folder -Path "DeviceCollection\Test Collections\Deployments" -Name "TESTING" -AutoCreatePath

Write-Host "...Color CHeck00000...." -ForegroundColor $ColSuccess
Write-Host "...Color CHeck00000...." -ForegroundColor $ColError
Write-Host "...Color CHeck00000...." -ForegroundColor $ColInform



# Create and move a new collection
Create-And-MoveCMCollection -CollectionName "MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn [Install] EZY" `
    -LimitingCollection "MS 365 Apps Semi-Annual Enterprise Channel (Preview) CDN" `
    -FolderPath "DeviceCollection\Security Management Services\Deployments\MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn"

# Add Include and Exclude Membership Rules
Add-IncludeCollection -SelectCollectionName "MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn [Install] EZY" `
    -IncludeCollectionNames @("MS 365 Apps Semi-Annual Enterprise Channel (Preview) 2402 x86", "MS 365 Apps Semi-Annual Enterprise Channel (Preview) 2402 x64")

Add-ExcludeCollection -SelectCollectionName "MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn [Install] EZY" `
    -ExcludeCollectionNames @("Desktop Testing Team EZY")



Remove-Module MySCCMModule -Force
Import-Module .\MySCCMModule.psd1 -Force

Get-YearMonth


# Check color variables
Get-Variable ColSuccess, ColError, ColInform


Initialize-SCCMEnvironment

New-CMDeviceCollectionInFolder -CollectionName "TEST_CRESTE_AND_MOVE" -LimitingCollection "All Windows Workstation or Professional Systems" -FolderPath "DeviceCollection\Reusable Collections\5 Percent Sets"
New-CMDeviceCollectionInFolder -CollectionName "TEST_CRESTE_AND_MOVE" -LimitingCollection "All Windows Workstation or Professional Systems" -FolderPath "DeviceCollection\Test Collections\Testing\ONe" -AutoCreateFolder
New-CMDeviceCollectionInFolder -CollectionName "TEST_CRESTE_AND_MOVE" -LimitingCollection "All Windows Workstation or Professional Systems" -FolderPath "DeviceCollection\Test Collections" #-AutoCreateFolder
New-CMDeviceCollectionInFolder -CollectionName "TEST_CRESTE_AND_MOVE" -LimitingCollection "All Windows Workstation or Professional Systems" -FolderPath "DeviceCollection\Test Collections\ONE\TWO\Three\" -AutoCreateFolder
New-CMDeviceCollectionInFolder -CollectionName "TEST_CRESTE_AND_MOVE" -LimitingCollection "All Windows Workstation or Professional Systems" -FolderPath "DeviceCollection\Test Collections\ONE\TWO\Three" -AutoCreateFolder


Create-And-MoveCMCollection -CollectionName "SMS_Collection_05Percent_Set_19" -LimitingCollection "All Windows Workstation or Professional Systems" -FolderPath "DeviceCollection\Reusable Collections\5 Percent Sets"


Get-Command -Module MySCCMModule
Get-Help New-CMDeviceCollectionInFolder

New-CMDeviceCollectionInFolder -CollectionName "TEST_CRESTE_AND_MOVE" -LimitingCollection "All Windows Workstation or Professional Systems" -FolderPath "DeviceCollection\Test Collections\ONE\TWO\Three\Four" -AutoCreateFolder

Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1"
